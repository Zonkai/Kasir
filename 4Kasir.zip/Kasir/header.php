<div class="header">
    <h4>Dashboard Kasir</h4>
    <a href="logout.php" class="btn btn-danger">Logout</a>
</div>
