<?php
require 'vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

session_start();
include 'koneksi.php';

$total_harga = 0;
if (isset($_SESSION['keranjang']) && !empty($_SESSION['keranjang'])) {
    foreach ($_SESSION['keranjang'] as $produk) {
        if (isset($produk['nama'], $produk['harga'], $produk['jumlah'], $produk['subtotal'])) {
            $total_harga += $produk['subtotal'];
        }
    }
} else {
    $total_harga = 0;
}

// Inisialisasi Dompdf
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$dompdf = new Dompdf($options);

// Konten HTML untuk PDF
$html = '
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Transaksi</title>
    <style>
        .container {
            width: 80%;
            margin: 0 auto;
        }
        .text-center {
            text-align: center;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            padding: 10px;
            border: 1px solid #000;
        }
        .total {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3 class="text-center">Struk Transaksi</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>';

if (isset($_SESSION['keranjang']) && !empty($_SESSION['keranjang'])) {
    foreach ($_SESSION['keranjang'] as $produk) {
        $html .= '<tr>
                    <td>' . (isset($produk['nama']) ? $produk['nama'] : 'Tidak Ditemukan') . '</td>
                    <td>Rp ' . (isset($produk['harga']) ? number_format($produk['harga'], 0, ',', '.') : '0') . '</td>
                    <td>' . (isset($produk['jumlah']) ? $produk['jumlah'] : '0') . '</td>
                    <td>Rp ' . (isset($produk['subtotal']) ? number_format($produk['subtotal'], 0, ',', '.') : '0') . '</td>
                  </tr>';
    }
} else {
    $html .= '<tr>
                <td colspan="4" class="text-center">Keranjang Belanja Kosong</td>
              </tr>';
}

$html .= '</tbody>
        </table>
        <div class="text-center total">
            <span>Total Harga: </span>
            <span>Rp ' . number_format($total_harga, 0, ',', '.') . '</span>
        </div>
    </div>
</body>
</html>';

// Load konten HTML ke Dompdf
$dompdf->loadHtml($html);

// (Opsional) Set ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'portrait');

// Render PDF
$dompdf->render();

// Output PDF ke browser
$dompdf->stream("transaksi.pdf", ["Attachment" => false]);
?> 