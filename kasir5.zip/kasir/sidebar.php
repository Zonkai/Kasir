<div class="sidebar" style="position: fixed; left: 0; top: 0;">
    <h2>Toko Gurwan</h2>
    <ul style="text-align: right;">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="data_produk.php">Data Produk</a></li>
        <li><a href="transaksi.php">Transaksi</a></li>
        <li><a href="laporan.php">Laporan</a></li>
        <li><a href="pengaturan.php">Pengaturan</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>
