<?php
session_start();
if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Kasir</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="icon" href="assets/favicon.ico" type="image/x-icon">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: url('assets/background.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .card {
            border-radius: 12px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
            background-color: rgba(255, 255, 255, 0.9); /* Transparansi */
        }
        .form-control {
            border-radius: 8px;
            padding-left: 40px; /* Untuk ikon */
        }
        .form-control-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
        }
        .btn-primary {
            background: linear-gradient(45deg, #007bff, #0056b3);
            border: none;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #0056b3, #003f7f);
            transform: scale(1.05);
        }
        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container" style="max-width: 400px;">
        <div class="card">
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <h1 class="display-5 fw-bold text-primary mb-3">Toko Gurwan</h1>
                    <p class="text-muted">Silahkan login untuk melanjutkan</p>
                </div>
                
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-danger mb-3" style="border-radius: 8px;">
                        <?php echo htmlspecialchars($_GET['error']); ?>
                    </div>
                <?php endif; ?>

                <form action="login.php" method="POST" class="position-relative">
                    <div class="mb-3 position-relative">
                        <i class="bi bi-person form-control-icon"></i>
                        <input type="text" class="form-control form-control-lg" name="username" placeholder="Username" required>
                    </div>
                    
                    <div class="mb-3 position-relative">
                        <i class="bi bi-lock form-control-icon"></i>
                        <input type="password" class="form-control form-control-lg" name="password" id="password" placeholder="Password" required>
                        <i class="bi bi-eye toggle-password" id="togglePassword"></i>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-lg w-100 mb-2 fw-bold">Masuk</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <script>
        const togglePassword = document.querySelector("#togglePassword");
        const passwordInput = document.querySelector("#password");

        togglePassword.addEventListener("click", function () {
            // Toggle tipe input antara 'password' dan 'text'
            const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
            passwordInput.setAttribute("type", type);

            // Toggle ikon antara 'eye' dan 'eye-slash'
            this.classList.toggle("bi-eye");
            this.classList.toggle("bi-eye-slash");
        });
    </script>
</body>
</html>
